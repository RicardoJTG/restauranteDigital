<template>
           
    <div class="container">
              <h1 id="titulo1">MENÚ</h1>
              <div class="row">
                <div class="col-4">
                  <img src="../assets/img/comida1.jpg" class="img-thumbnail" alt="Arepa">
                  <center><button type="button" class="btn btn-primary btn-sm posi">Agregar</button></center>
                </div>
                <div class="col-4">
                  <img src="../assets/img/comida1.jpg" class="img-thumbnail" alt="Burguer">
                  <center><button type="button" class="btn btn-primary btn-sm posi">Agregar</button></center>
                </div>
              </div>
              <div class="row">
                <div class="col">
                  <img src="../assets/img/comida1.jpg" class="img-thumbnail" alt="Burguer">
                  <center><button type="button" class="btn btn-primary btn-sm posi">Agregar</button></center>
                </div>
                <div class="col">
                  <img src="../assets/img/comida1.jpg" class="img-thumbnail" alt="Burguer">
                  <center><button type="button" class="btn btn-primary btn-sm posi">Agregar</button></center>
                </div>
              </div>
              <div class="row">
                <div class="col">
                  <img src="../assets/img/comida1.jpg" class="img-thumbnail" alt="Burguer">
                  <center><button type="button" class="btn btn-primary btn-sm posi">Agregar</button></center>
                </div>
                <div class="col">
                  <img src="../assets/img/comida1.jpg" class="img-thumbnail" alt="Burguer">
                  <center><button type="button" class="btn btn-primary btn-sm posi">Agregar</button></center>
                </div>
            </div>
            
    </div>

    
</template>

<style>


#titulo1{
  text-align: center;
  background: white;
  

}



</style>