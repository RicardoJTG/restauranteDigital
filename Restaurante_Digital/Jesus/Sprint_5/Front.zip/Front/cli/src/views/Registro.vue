<template>
    <div class="container">
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Correo electrónico</label>
                <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="ejemplo@example.com">
            </div>

            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Nombre</label>
                <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Pepito Perez">
            </div>

            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Número Celular</label>
                <input type="email" class="form-control" id="exampleFormControlInput1">
            </div>

            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault" checked>
                <label class="form-check-label" for="flexCheckDefault">
                  Política de <a href="#">tratamiento de datos</a>
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked">
                <label class="form-check-label" for="flexCheckChecked">
                  Acepta el envío de información promocional
                </label>
            </div>
            <br>
            <button type="button" class="btn btn-success">Registrarse</button>

        </div> 
</template>