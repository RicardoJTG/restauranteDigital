<template> 
  <PaginaInicial/> 
  
</template>

<script>
  import  PaginaInicial from './PaginaInicial.vue'

  export default {
    name: 'Home',

    components: {
      
      PaginaInicial,
    },
  }
</script>