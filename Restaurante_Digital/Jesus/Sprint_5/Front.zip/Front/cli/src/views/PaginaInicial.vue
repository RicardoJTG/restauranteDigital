<template>
    <div> 
        <Center>
            <img src= "../assets/img/comida1.jpg" alt="23" srcset="">
        </Center>
    </div>
</template>

<style>
img{
    height: 300px;
    margin: 52px;
    margin-top: 15px;
    margin-bottom: 15px;
}
</style>