<template>
    <div class="row">
        <div class="col">
            <h1 id="titulo">Restaurante Digital</h1>
        </div>
    </div>
</template>


<script>
export default {
    
}
</script>


<style>

*{
    padding: 0%;
    margin: 0%;
    font-family: "Times New Roman"; 
}

#titulo {
    text-align: center;
    background-color: rgb(55, 70, 70);
    color: rgb(252, 245, 245);
    height: 70px;
    padding: 6px;
    margin: 70px;
    margin-top: 10px;
    margin-bottom: 5px;

    
}

/*header{
    background-color: rgb(55, 70, 70);
    height: 90px;
}*/

/*header h1{
    color: rgb(252, 245, 245);
    margin-left: 20px;
    padding: 20px;

}*/
</style>