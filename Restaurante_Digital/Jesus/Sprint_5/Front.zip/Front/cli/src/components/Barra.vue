<template>
    <nav id="barra" class="ml-23">
        <router-link to="/inicio">Home</router-link> |
        <router-link to="/login">Iniciar sesión</router-link> |
        <router-link to="/registro">Crear Usuario</router-link> |
        <router-link to="/productos">Productos</router-link>

    </nav>
</template>


<style>
#barra{
    background-color: #E6E6E6;
    padding: 20px;
    margin: 70px;
    margin-top: -3px;
    margin-bottom: 10px;
   
    
}

#barra1 a{
    color: black;
    margin-left: 12px;
    text-decoration: none;

}
</style>

